const fortunes = [
    "You will have a great day!",
    "An exciting opportunity awaits you.",
    "Good news is coming your way.",
    "Your hard work will pay off soon.",
    "A surprise is in store for you.",
    "You will meet someone important today.",
    "Happiness is around the corner.",
    "A new adventure is about to begin.",
    "Stay positive, good things will come.",
    "Believe in yourself and success will follow."
];

function getRandomFortune() {
    const index = Math.floor(Math.random() * fortunes.length);
    return fortunes[index];
}

document.getElementById("fortuneBox").innerText = getRandomFortune();

function changeFontColor() {
    document.getElementById("fortuneBox").style.color = getRandomColor();
}

function changeBgColor() {
    document.getElementById("fortuneBox").style.backgroundColor = getRandomColor();
}

function changeBorderColor() {
    document.getElementById("fortuneBox").style.borderColor = getRandomColor();
}

function changeFontStyle() {
    const fonts = ["Arial", "Verdana", "Times New Roman", "Georgia", "Courier New"];
    const sizes = ["18px", "20px", "22px", "24px", "26px"];
    document.getElementById("fortuneBox").style.fontFamily = fonts[Math.floor(Math.random() * fonts.length)];
    document.getElementById("fortuneBox").style.fontSize = sizes[Math.floor(Math.random() * sizes.length)];
}

function getRandomColor() {
    return `#${Math.floor(Math.random() * 16777215).toString(16)}`;
}
