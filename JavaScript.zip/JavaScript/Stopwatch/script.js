let time = 0;
let interval;

function startTimer() {
    if (!interval) {
        interval = setInterval(() => {
            if (time < 30) {
                time += 3;
                document.getElementById("display").textContent = time;
            } else {
                clearInterval(interval);
                interval = null;
            }
        }, 3000);
    }
}

function stopTimer() {
    clearInterval(interval);
    interval = null;
}

function resetTimer() {
    stopTimer();
    time = 0;
    document.getElementById("display").textContent = time;
}

document.getElementById("start").addEventListener("click", startTimer);
document.getElementById("stop").addEventListener("click", stopTimer);
document.getElementById("reset").addEventListener("click", resetTimer);
